
import pandas as pd
import re, json, time
from collections import defaultdict, Counter

"""
    Como primer paso el algoritmo debe ser capaz de detectar subconjuntos de renglones en donde al menos tres columnas tengan
    valores iguales. Los renglones en donde una columna tenga valor null o este vacía se consideran también como valores iguales.
"""
"""
    Javi Git Masterclass 240625
"""

"""
    290425

    Los ORs en su mayoría se quedan iguales, pero hay que detectar los que no se están usando y borrarlos.

    El algoritmo ignorará los renglones que comiencen con la palabra reservada DEFINE.

    Cuando se detecte las palabras TABLE TYPE: PICK ONE o PICK ALL, estamos frente a una tabla.

    Dentro del cuerpo de una tabla, la primer columna contendrá las letras D, R o C, que indican el tipo de renglón.
    D = Disabled, R = Rule, C = Comment.

    Los Disabled los ignoramos, y nos concentramos en optimizar los renglones que comienzan con R.

    La segunda columna, típicamente contiene el nombre de la tabla debajo de el nombre de columna description

    Dentro de una tabla las columnas están separadas por n espacios en blanco, donde n está determinado por el valor más largo de columna

    Los primeros cuatro renglones de toda tabla contienen la misma estructura, a saber:

    1. El tipo de tabla
    2. El nombre de las columnas, en donde el nombre de la primer columna corresponde al nombre de la tabla
    3. Indicador del tipo de columna. Las columnas pueden ser solo de dos tipos: input y output.
    4. Tipo de dato esperado en la columna. ALPHA, NUM, FLOAT, REAl, RANGE, etc.

    080525

    Hay una tabla que se llama Global ORs.


"""

class LogicalRules:

    def __init__(self):

        self._variableName = None
        self._type = None
        self._listOfValues = []
        
    @property
    def variableName(self):
        return self._variableName
        
    @property
    def type(self):
        return self._type
    
    @property
    def listOfValues(self):
        return self._listOfValues
    
    @variableName.setter
    def variableName(self, variableName):
        self._variableName = variableName
        
    @type.setter
    def type(self, type):
        self._type = type
    
    @listOfValues.setter
    def listOfValues(self, listOfValues):
        self._listOfValues = listOfValues

    # -----------------------------------------------------------------------------------------------

    def Tokenizer(self, string, delimiter):
        
        tokens = []
            
        while(string.find(delimiter)!=-1):
            
            string = string.partition(delimiter)
                            
            tokens.append(string[0])
            
            string = string[2]
        
        tokens.append(string)
        
        return tokens

    # -----------------------------------------------------------------------------------------------

    def RemoveTrash(self, strToBeCleaned, trash):

        return re.sub(trash, '', strToBeCleaned)
    
    # -----------------------------------------------------------------------------------------------

    def ReadLogicalRules(self, row, delimeters):
                
        # We need the string representation of the n-th row. With row.values we get a list
        # where each element represents the value of a column.
        rowValues = row.values
        strRow = ""

        # We then form the string representation by concatenating each element of the list.
        for rowValue in rowValues:
            strRow += str(rowValue)

        # We invoke the Tokenizer method using the character ':' as the delimiter. This produces
        # a list where the 0th element is formed by the keyword DEFINE, a whitespace character
        # , and the keyword OR. Given that this part of the structure of the prn file format
        # is constant, we can get rid of the keyword DEFINE and the whitespace character by
        # slicing the content of the 0th element as shown here.                
        tokens = self.Tokenizer(strRow, delimeters[0])
        self.type = tokens[0][6:]

        # We then invoke the Tokenizer method using the character '=' as the delimiter. This
        # will give us the name of the variable in the first position of the resulting list.
        # 130525
        # ['DEFINEOR', 'Poles', '2-3=2 Pole;3 Pole']
        # There are some cases where the variable names is split into two elements, so we need
        # to concatenate them before the next tokenization step.
        if len(tokens) > 2:
                    
            tokens[1] = tokens[1] + tokens[2]
            tokens.pop(2)

        tokens = self.Tokenizer(tokens[1], "=")
        self.variableName = tokens[0]

        # To get the list of values that the variable can take, we need to perform a series
        # of steps: 1) invoke the Tokenizer method using the ';' as the delimiter; 2) obtain
        # the last element of the list of values allowed for the variable; 3) remove the 
        # undesired content in the string that represents the last value of the list; 4)
        # substitute the last element of the list with the one that has been cleaned up;
        # and 5) assign the new list of values to the corresponding attribute of the
        # LogicalRules instance.
        tokens = self.Tokenizer(tokens[1], delimeters[1])

        lastElement = tokens[len(tokens)-1]
        lastElement = self.RemoveTrash(lastElement, 'nan')
        tokens[len(tokens)-1] = lastElement
                
        self.listOfValues = tokens

        return self        
    
# ===================================================================================================
    
class Table:

    def __init__(self):

        self._name = None
        self._typeOfTable = None
        self._typeOfColumn = None
        self._dataType = None
        self._columnWidths = []
        self._columns = []
        self._rows = []
        self._table = None
        
    @property
    def name(self):
        return self._name
    
    @property
    def typeOfTable(self):
        return self._typeOfTable

    @property
    def typeOfColumn(self):
        return self._typeOfColumn

    @property
    def dataType(self):
        return self._dataType            

    @property
    def columnWidths(self):
        return self._columnWidths

    @property
    def columns(self):
        return self._columns
    
    @property
    def rows(self):
        return self._rows  

    @property
    def table(self):
        return self._table  

    @name.setter
    def name(self, name):
        self._name = name

    @typeOfTable.setter
    def typeOfTable(self, typeOfTable):
        self._typeOfTable = typeOfTable

    @typeOfColumn.setter
    def typeOfColumn(self, typeOfColumn):
        self._typeOfColumn = typeOfColumn

    @dataType.setter
    def dataType(self, dataType):
        self._dataType = dataType                        

    @columnWidths.setter
    def columnWidths(self, columnWidths):
        self._columnWidths = columnWidths

    @columns.setter
    def columns(self, columns):
        self._columns = columns

    @rows.setter
    def rows(self, rows):
        self._rows = rows

    @table.setter
    def table(self, table):
        self._table = table

    # -----------------------------------------------------------------------------------------------

    def Tokenizer(self, string, delimiter):
        
        tokens = []
            
        while(string.find(delimiter)!=-1):
            
            string = string.partition(delimiter)
                            
            tokens.append(string[0])

            if len(string[0]) >= 1:
                tokens.append(string[1])
            
            string = string[2]
        
        tokens.append(string)
        
        return tokens

    # -----------------------------------------------------------------------------------------------

    def RemoveTrash(self, strToBeCleaned, trash):

        return re.sub(trash, '', strToBeCleaned)
    
    # -----------------------------------------------------------------------------------------------

    def ReadTable(self, row, delimeters, keyword):

        # We need the string representation of the n-th row. With row.values we get a list
        # where each element represents the value of a column.
        rowValues = row.values
        strRow = ""

        # We then form the string representation by concatenating each element of the list.
        for rowValue in rowValues:
            strRow += str(rowValue)

        strRow = self.RemoveTrash(strRow, 'nan')

        if keyword == "TABLE TYPE":

            # We invoke the Tokenizer method using the character ':' as the delimiter. This produces
            # a list where the 0th element is formed by the words TABLE TYPE and the 1st element contains
            # the value of the table type.
            tokens = self.Tokenizer(strRow, delimeters[0])

            self.typeOfTable = tokens[2].lstrip()

        elif keyword == "HEADING":

            columns = ""

            for value in rowValues:
                
                if pd.isna(value):
                    continue

                columns = value
            
            # --- for value in rowValues: -------------------------------------------------------------------

            columns = self.Tokenizer(columns, ' ')

            lengthOfBlanks = 0

            widthOfBlanks = []
            widthOfWords = [] 

            # --- 140825 ---------------------------------------------
            # Index 2 skips ['HEADING', ' ', 'Description', ' ', ...]
            # HEADING and Description are not considered as columns.
            # --------------------------------------------------------

            for t in columns[2:]:

                if t == '' or t == ' ':

                    lengthOfBlanks += 1
                
                else:

                    widthOfBlanks.append(lengthOfBlanks)
                    lengthOfBlanks = 0

            for t in columns[2:]:

                if t != '' and t != ' ':

                    widthOfWords.append(len(t))

            for index, t in enumerate(columns[2:]):

                try:

                    width = widthOfWords[index] + widthOfBlanks[index+1]
                    self.columnWidths.append(width)

                except IndexError:

                    pass
            
            # ------------------------------------------------------------------------

            cleanedColumns = []

            for c in columns:

                if c != '' and c != ' ':

                    cleanedColumns.append(c)

            # ------------------------------------------------------------------------

            # --- 140825 ---------------------------------------------
            # Index 2 skips ['HEADING', 'Description', ...]
            # HEADING and Description are not considered as columns.
            # --------------------------------------------------------

            self.columns = cleanedColumns[1:]

        elif keyword == "I/O":

            typesOfColumn = ""

            for value in rowValues:
                
                if pd.isna(value):
                    continue

                typesOfColumn = value
            
            # --- for value in rowValues: --------------------------------------------

            typesOfColumn = self.Tokenizer(typesOfColumn, ' ')

            # ------------------------------------------------------------------------

            cleanedTypesOfColumn = []

            for c in typesOfColumn:

                if c != '' and c != ' ':

                    cleanedTypesOfColumn.append(c)

            # ------------------------------------------------------------------------

            self.typeOfColumn = cleanedTypesOfColumn[1:]
        
        elif keyword == "TYPE":

            dataTypes = ""
            
            for value in rowValues:
                
                if pd.isna(value):
                    continue

                dataTypes = value
            
            # --- for value in rowValues: -------------------------------------------------------------------

            dataTypes = self.Tokenizer(dataTypes, ' ')

            # ------------------------------------------------------------------------

            cleanedDataTypes = []

            for c in dataTypes:

                if c != '' and c != ' ':

                    cleanedDataTypes.append(c)

            # ------------------------------------------------------------------------

            self.dataType = cleanedDataTypes[1:]

        elif keyword == "R" or keyword == "D" or keyword == "C":

            """
            180525
            
            + El último elemento de la lista de tokens contendrá el valor de la columna output y será tokeniz-
              ado utilizando el delimitador ; para obtener la lista de valores permitidos para la columna.

            """

            """
            050625

            + No encontramos una manera universal de realizar la tokenización, así que optamos por utilizar un
              sólo espacio en blanco. Esta decisión implica renunciar a la idea de asignar el valor correspond-
              iente a cada columna. La hipótesis es que no necesitamos ese nivel de precisión para operar los
              algoritmos de optimización que representan el núcleo de la herramienta.

            """
            rules = self.Tokenizer(strRow, " ")

            copyOfRules = rules.copy()
            #copyOfRules = [item for item in copyOfRules if item != '' and item != ' ']
            copyOfRules = [item for item in copyOfRules if item != '']
    
            try:
                self.name = copyOfRules[2].lstrip()
            except:
                self.name = [f"COULDNOTFINDTABLENAME_{i}" for i in range(1, 500)]
            self.rows.append(rules)
     
    # -----------------------------------------------------------------------------------------------

    def WriteTable(self, fileHandler):
            
        # Write the table type
        fileHandler.write(f"TABLE TYPE: {self.typeOfTable}\n")

        # Write the columns
        fileHandler.write("HEADING Description " + " ".join(self.columns) + "\n")

        # Write the type of columns
        fileHandler.write("I/O: " + " ".join(self.typeOfColumn) + "\n")

        # Write the data types
        fileHandler.write("TYPE  " + " ".join(self.dataType) + "\n")

        # Write the rows
        for row in self.rows:
            fileHandler.write(" ".join(row) + "\n")

    # -----------------------------------------------------------------------------------------------

# ===================================================================================================
    
    def BuildTable(self):

        columns = ["HEADING"] + self.columns

        self._table = pd.DataFrame(columns=columns)

        for idxr, r in enumerate(self.rows):

            decompRow = [list(item) if item else [''] for item in r]
            flattenedDecompRow = [char for sublist in decompRow for char in sublist]

            start = 0 # index included
            end = 8 # index excluded
            self._table.loc[idxr,"HEADING"] = ''.join(flattenedDecompRow[start:end])

            for idxc, c in enumerate(self.columns):

                try:

                    start = end
                    end = start + self.columnWidths[idxc]

                    if len(flattenedDecompRow[start:end]) < self.columnWidths[idxc]:

                        self._table.loc[idxr,self.columns[idxc]] = ''.join(flattenedDecompRow[start:end]) + " "

                    else:

                        self._table.loc[idxr,self.columns[idxc]] = ''.join(flattenedDecompRow[start:end])

                except IndexError:

                    self._table.loc[idxr,self.columns[idxc]] = ''.join(flattenedDecompRow[start:])

            # --- for idxc, c in enumerate(columns[2:]): --------------------------------------------

        # --- for idxr, r in enumerate(self.rows): --------------------------------------------------

# ===================================================================================================

class PrnDoctor:

    def __init__(self, file):

        self._pathAndNameOfTheFile = file
        self._fileHandler = pd.read_fwf(file, header=None, widths=[500]*10)
        self._delimiters = None
        self._fileHandler = self._fileHandler.dropna(how='all')
        self._fileHandler = self._fileHandler.reset_index(drop=True)
        self._logicalRules = []
        self._tables = []

    # --- def __init__(self, file): ----------------------------------------------------------------


    """
    
        @property
        
        * The @property decorator is used to define a method as a property. This allows 
          you to access the method like an attribute, without needing to call it as a method.
          
        * It is a way to encapsulate the access to an attribute, providing a getter method that 
          can include additional logic if needed.

        def pathAndNameOfTheFile(self):
        
        * This line defines a method named pathAndNameOfTheFile within a class. The self parameter 
          refers to the instance of the class.

        * By using the @property decorator, this method will be treated as a property, meaning you 
          can access it like an attribute.
        
        return self._pathAndNameOfTheFile

        * This line returns the value of the private attribute _pathAndNameOfTheFile.
        
        * The underscore (_) prefix is a common convention in Python to indicate that the attribute 
          is intended to be private and should not be accessed directly from outside the class.
    
    """

    @property
    def pathAndNameOfTheFile(self):
        return self._pathAndNameOfTheFile
    
    @property
    def fileHandler(self):
        return self._fileHandler
    
    @property
    def getDelimiters(self):

        firstRow = self._fileHandler.iloc[0]
        
        for column in self._fileHandler.columns:

            if pd.isna(firstRow[column]):
                continue

            if "DELIMITER" in firstRow[column]:

                offset = len(firstRow[column])
                self._delimiters = firstRow[column][offset-2:]

        return self._delimiters

    @property
    def logicalRules(self):
        return self._logicalRules
    
    @logicalRules.setter
    def logicalRules(self, rule):
        self._logicalRules.append(rule)

    @property
    def tables(self):
        return self._tables
    
    @tables.setter
    def tables(self, table):
        self._tables.append(table)

    # -----------------------------------------------------------------------------------------------

    def Tokenizer(self, string, delimiter):
        
        tokens = []
            
        while(string.find(delimiter)!=-1):
            
            string = string.partition(delimiter)
                            
            tokens.append(string[0])
            
            string = string[2]
        
        tokens.append(string)
        
        return tokens
    
    # --- def Tokenizer(string,delimiter): ----------------------------------------------------------

    def RemoveTrash(self, strToBeCleaned, trash):

        return re.sub(trash, '', strToBeCleaned)
    
    # --- def RemoveTrash(self, strToBeCleaned, trash): ---------------------------------------------

    def ReadPRN(self):
    
        for index, row in self._fileHandler.iterrows():

            # If the row is empty or if it is the first row, we skip it.
            if pd.isna(row.iloc[0]) or index == 0:
                continue
            
            # We check for the occurrence of the keyword DEFINE in the first column of the n-th row.
            # All rows that start with DEFINE will be stored and handled by the instance of the
            # class LogicalRules.
            if row.iloc[0].startswith("DEFINE"):

                # We create an instance of the LogicalRules for each iteration of the for loop.        
                logRls = LogicalRules()

                delimeters = self.getDelimiters

                logRls.ReadLogicalRules(row, delimeters)

                # We then append the LogicalRules instance to the list of logical rules.
                self.logicalRules = logRls

                continue
            
            # --- if row.iloc[0].startswith("DEFINE") ----------------------------------------------            
            
            # We check for the occurrence of the keyword TABLE in the first column of the n-th row.
            # All rows that start with TABLE will be stored and handled by the instance of the
            # class Tables.            
            if row.iloc[0].startswith("TABLE"):

                # We create an instance of the Table object for each iteration of the for loop.        
                tbl = Table()

                delimeters = self.getDelimiters

                # row.iloc[0][:10] -> "TABLE TYPE"
                tbl.ReadTable(row, delimeters, row.iloc[0][:10])

                # We then append the Table instance to the list of Tables.
                self.tables = tbl
            
            # --- if row.iloc[0].startswith("TABLE"): ----------------------------------------------  

            if row.iloc[0].startswith("HEADING"):

                # row.iloc[0][:7] -> "HEADING"
                tbl.ReadTable(row, delimeters, row.iloc[0][:7])

            # --- if row.iloc[0].startswith("HEADING"): --------------------------------------------  

            if row.iloc[0].startswith("I/O"):

                # row.iloc[0][:3] -> "I/O"
                tbl.ReadTable(row, delimeters, row.iloc[0][:3])

            # --- if row.iloc[0].startswith("I/O"): ------------------------------------------------

            if row.iloc[0].startswith("TYPE"):

                # row.iloc[0][:4] -> "TYPE"
                tbl.ReadTable(row, delimeters, row.iloc[0][:4])

            # --- if row.iloc[0].startswith("TYPE"): -----------------------------------------------

            if row.iloc[0].startswith("R") or row.iloc[0].startswith("D") or row.iloc[0].\
               startswith("C"):

                # row.iloc[0][0] -> "R, C, D"
                tbl.ReadTable(row, delimeters, row.iloc[0][0])

            # --- if row.iloc[0].startswith("TYPE"): ------------------------------------------------

    # --- def read(self): ---------------------------------------------------------------------------

    def OptimizationOne(self):
        """
        Optimizes tables by reducing duplicate rows while preserving original order.
        - Works on grouped logic (construct column).
        - Replaces block of rows with one reduced row at the original start index.
        - Keeps HEADING, Description, and last column unchanged.
        - Generates OR mappings for differing values.
        Returns:
            reduced_tables: dict {table_name: optimized DataFrame}
            global_or_mapping: dict {table_name: {OR_name: [values]}}
        """
        self.ReadPRN()
        reduced_tables = {}
        global_or_mapping = {}

        for index, item in enumerate(self.tables):
            item.BuildTable()
            table = item.table
            tableName = item.name
            columns = list(table.columns)

            if tableName not in columns:
                continue

            # Identify columns to ignore
            ignore_cols = {'HEADING', 'Description', columns[-1]}
            compare_cols = [col for col in columns if col not in ignore_cols]

            # Find duplicates
            duplicated_rows = table[table.duplicated(subset=tableName, keep=False)]
            grouped = duplicated_rows.groupby(tableName)

            # Work on a copy to preserve order
            optimized_table = table.copy()
            or_mapping = {}

            for _, group in grouped:
                # Filter out Disabled rows
                group = group[group['HEADING'].str.strip() != 'D']
                if group.empty:
                    continue

                start_idx = group.index.min()  # First index of the group
                # Build reduced row
                base_row = group.iloc[0].copy()

                for index, col in enumerate(compare_cols):
                    unique_vals = group[col].dropna().unique()

                    if len(unique_vals) > 1:
                        or_name = f"{col}OrValues{index}"
                        base_row[col] = or_name
                        or_mapping[or_name] = list(unique_vals)
                    else:
                        base_row[col] = unique_vals[0] if len(unique_vals) > 0 else ''

                # Remove original group rows
                optimized_table.drop(index=group.index, inplace=True)
                # Insert reduced row at start index
                before = optimized_table.loc[:start_idx - 1]
                after = optimized_table.loc[start_idx:]
                optimized_table = pd.concat([before, pd.DataFrame([base_row]), after])

            # Reset index for clean output
            optimized_table.reset_index(drop=True, inplace=True)
            reduced_tables[item.name] = optimized_table
            global_or_mapping[item.name] = or_mapping

            # table.to_csv(f'input{tableName}.csv', index=False)
            # optimized_table.to_csv(f'output{tableName}.csv', index=False)
            print('================================ BEFORE ================================')
            print(table)
            print('================================ AFTER ================================')
            print(optimized_table)
        return reduced_tables, global_or_mapping
   
   
    # def OptimizationOne(self):

    #     """
    #         This method is intended to optimize the logical rules and tables.
    #         The optimization process will be implemented in future versions.
    #     """
    #     self.ReadPRN()


    #     def analyze_duplicate_rows(table, subset_column='construct'):
    #         tempTable = table
    #         # Find all rows that are duplicated based on the subset_column
    #         duplicated_rows = table[table.duplicated(subset=subset_column, keep=False)]
    #         # Group duplicated rows by the subset_column
    #         grouped = duplicated_rows.groupby(subset_column)
    #         # Initialize a counter to summarize comparisons
    #         # List to store generated definitions
    #         definitions = []

    #         # Identify columns to compare (excluding first, second, last, and the subset_column itself)
    #         all_columns = list(table.columns)
    #         excluded_indices = { 0, 1 }
    #         # excluded_indices = {0, 1, len(all_columns) - 1}
    #         columns_to_compare = [
    #             col for idx, col in enumerate(all_columns)
    #             if idx not in excluded_indices and col != subset_column
    #         ]


    #         # Iterate through each group of duplicates
    #         for _, group in grouped:
    #             filtered_group = group[group['HEADING'] != 'D ']
    #             print(filtered_group)
    #             print("FOREACH COLUMNS")
    #             for column in filtered_group.columns:
    #                 value_counts = group[column].value_counts()

    #                 # print(f"Column: {column}")
    #                 # print(value_counts)
    #                 # print(f"Group length: {len(filtered_group)}")

    #             print("ENDS GROUP\n\n\n")
                        
    #             # print(f"\n\n\nDIFFERENT COLS {different_columns}\n")
    #             # print(f"EQUAL COLS {equal_columns}\n\n\n")

    #         # Print generated definitions
    #         # if definitions:
    #         #     print("Generated Definitions:")
    #         #     for definition in definitions:
    #         #         print(definition)

    #     # Use this inside your loop
    #     for item in self.tables:
    #         item.BuildTable()
    #         table = item.table
    #         print(f"Analyzing table: {item.name}")
    #         analyze_duplicate_rows(table, subset_column='construct')
    #         print("----------------------")

                


    def EqualTokensDetector(self):

        #print(self.tables)

        # Imprimiendo los atributos del objeto Table.

        """
            self._name = None
            self._typeOfTable = None
            self._typeOfColumn = None
            self._dataType = None
            self._columns = []
            self._rows = []
        """

        #print(f"Name: {self.tables[0].name}")
        #print(f"Type of Table: {self.tables[0].typeOfTable}")
        print("\n")
        print(f"Type of Column: {self.tables[0].typeOfColumn}")
        print(f"Columns: {self.tables[0].columns}")
        print("\n")
        #print(f"Data Type: {self.tables[0].dataType}")
        #print(f"Columns: {self.tables[0].columns}")
        #print(self.tables[0].rows)

        print("----------------")
        print(len(self.tables[0].typeOfColumn))
        print("----------------")

        for row in self.tables[0].rows:
            if len(row) >= len(self.tables[0].typeOfColumn):
                row[len(self.tables[0].typeOfColumn)] = 'FOUND_POSITION'
                print(row)
                
                #print(len(row))
                #print(row)
                #print("***")
                #print(row[len(self.tables[0].typeOfColumn)-3])
                #print(row[len(self.tables[0].typeOfColumn)-2])
                #print(row[len(self.tables[0].typeOfColumn)-1])



    

        #print("\n")

        #print(f"Name: {self.tables[1].name}")
        #print(f"Type of Table: {self.tables[1].typeOfTable}")
        #print(f"Type of Column: {self.tables[1].typeOfColumn}")
        #print(f"Data Type: {self.tables[1].dataType}")
        #print(f"Columns: {self.tables[1].columns}")
        #print(self.tables[1].rows)

    def WritePRN(self, fileName):

        with open(fileName, 'w') as file:

            # Write the delimiters
            file.write(f"DEFINE DELIMITER{self._delimiters}\n")

            # Write the logical rules
            for rule in self.logicalRules:
                file.write(f"DEFINE OR:{rule.variableName}={';'.join(rule.listOfValues)}\n")

            # Write the tables
            for table in self.tables:
                table.WriteTable(file)

# ===================================================================================================